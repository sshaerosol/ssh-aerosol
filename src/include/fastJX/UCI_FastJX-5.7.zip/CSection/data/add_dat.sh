for fich in $(/bin/ls -Sr *RADM88)
do
  cp $fich ${fich}.dat
done
